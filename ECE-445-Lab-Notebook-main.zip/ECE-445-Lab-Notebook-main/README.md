# ECE-445-Lab-Notebook

This repository will document my progress for my Senior Design Project.
We will be building a Persistence of Vision globe that has rgb leds, wifi connectivity for use with web app, and a resolution of 64 * 256.

# 09-25-25
Met with the team and TA to discuss available components and our plan for the breadboard demo. I brought my ESP32 dev kit. The TA recommended displaying something on a spinning board to demonstrate persistence of vision on a small scale. We considered using about 8 LEDs.

We downloaded the Arduino IDE, configured it to recognize our board (similar to the soldering demo), and successfully turned on a 4-pin LED using test code.

#define LED_PIN 25   // GPIO pin for LED

void setup() {
  pinMode(LED_PIN, OUTPUT);  // set pin as output
}

void loop() {
  digitalWrite(LED_PIN, HIGH);  // LED on
  delay(500);                   // wait 0.5 s
  digitalWrite(LED_PIN, LOW);   // LED off
  delay(500);                   // wait 0.5 s
}

Afterward, we picked up some Hall sensors from the electronics shop but had trouble locating the correct datasheet.
https://www.farnell.com/datasheets/2619483.pdf 

Our first attempt connected the Hall sensor directly to an LED, expecting it to light when the sensor detected a magnetic field. This setup did not work.
 ![Image](https://github.com/user-attachments/assets/1392a53e-122f-4665-862b-3ed59b381540)

Our second attempt involved reading the Hall sensor through Arduino and printing a message when a magnetic field was detected. This also failed.

We decided to set the Hall sensor aside for the day.

# 09-29-25
Using a protoboard and the ESP32, we started planning how to solder components. Power was a challenge because the entire board needs to spin, and a large battery would be too heavy. We chose to use two 3V coin cell batteries in series, along with casings to mount them on the board. There was a brief misunderstanding with my teammate about wiring the ESP32 to the batteries.
![Image](https://github.com/user-attachments/assets/9285b9c8-4173-4628-96bf-127159e7a688)

We soldered a resistor and LED, then added wiring for future connections. 
![Image](https://github.com/user-attachments/assets/137cf1e6-e8db-4db0-a1cd-e312bcd3a742)
![Image](https://github.com/user-attachments/assets/c4e3ecba-e106-4899-8fbc-da01503ead1b)

After programming the ESP32, we tested the setup with battery power, and it worked.

https://github.com/user-attachments/assets/10f2f32d-2df7-43ea-962c-cda01df8cdcb

We revisited the Hall sensor and discovered the output pin needed to be tied to power. We also realized it was a latching Hall sensor: the LED stayed on when one magnetic pole was detected and only turned off when the opposite pole was present.

# 09-30-25

Soldered additional LED–resistor pairs onto the board. Two of them did not work after programming. We re-soldered, but the issue persisted. It turned out the pins we used were not valid output pins. We rewired the LEDs to usable GPIO pins, and they worked.
![Image](https://github.com/user-attachments/assets/42501361-064b-4230-9a08-ec664eed97de)

https://github.com/user-attachments/assets/937a27fe-500e-4774-90c7-c7ef36f36d2e


We again tested the Hall sensor and confirmed the latching behavior: one pole turned the LED on, and the opposite pole turned it off.

# 10-02-25
Objectives
	•	Investigate why the quarter-cell battery pack failed after short operation time.
	•	Determine whether insufficient current delivery was causing ESP32 brownouts.
  
The quarter-cell batteries powering the ESP32-WROOM-32 dev kit were repeatedly failing after a brief period of operation. The device would boot, run for a moment, and then fully power off. Today’s goal was to determine whether the issue was a voltage drop, a current shortage, or a combination of both.

First observation: immediately after installing fresh quarter cells, the ESP32 successfully powered up, but within minutes, voltage sagged enough to trigger brownout reset behavior.

Using the datasheet values for ESP32 peak consumption (~500–700 mA during WiFi spikes, ~80–260 mA typical), it became clear that the small batteries were not supplying enough sustained current, even if the nominal voltage was nominally correct.

I verified this by measuring the battery pack voltage under load:
	•	No-load reading: ~4.6 V
	•	Under ESP32 load: sag down to ~3.2 V within ~5–10 seconds
This confirmed internal resistance was too high.

# 10-07-25
Had first breadboard demonstration. We showed what we had been working on and what has and hasn't been working. Brainstormed ideas on what other power could be used to power our prototype.
Decided on 4 AA batteries rated for 1.5 V since it gives us roughly 6 V which is slightly more than what the breadboard needs but should still work.

# 10-09-25
Began soldering the 4 AA battery casings to a protoboard and measured the output volatge of the batteries in their casing to be ~6.3 V. Tested the ESP32 dev board with this new power and it seemed to turn on just fine.
![Image](https://github.com/user-attachments/assets/f7d6602a-76e3-4003-abf4-0e399de71b8d)

# 10-14-25
Soldered the 16 led-resistor pairs to the protoboard, made sure to test if they all turned on. First time around most of them turned on but had to desolder and resolder some of the led-resistor pairs to the ESP32 dev kit. Also soldered hall sensor to board on the bottom of the board
![IMG_4863](https://github.com/user-attachments/assets/2456df77-56b3-4368-bbb0-a893273596a5)

# 10-16-25
Made hole on protoboard and the motor shaft was connected to protoboard with super glue, it was left to cure.

# 10-21-25
Tested prototype to see if it spun in with reasonable stability. Began writing new code for this new prototype specifically how the hall sensor would be best utilized.
![IMG_4866](https://github.com/user-attachments/assets/bc9e10ba-dcc8-4ccf-b225-cec8e036c4f6)

# 10-23-25
Figured out the best way to use the hall sensor. Setting up an interrupt when the hall sensor is detected to then do something seemed like a reasonable approach however first tests did not work as intented.
Here is some code that seemed promising. 
<img width="955" height="856" alt="image" src="https://github.com/user-attachments/assets/deeae1c2-f194-47c4-a545-ad7e47961734" />

# 10-28-25
Put together some code that seemed to display some figures like a cross and half circle while rotating the led display.
Demoed it to TA and Professor.
*See hello.ino, sketch_oct22a.ino, and Web_App_Test.ino*

# 10-30-25
I soldered the microSD module to the protoboard today and used the recommended ESP32 pins so the SPI connection would work without issues.
When I tested it, the SD card initialized, but none of the images would load. The web app stayed empty and the serial monitor kept printing my “failed to open file” message.
After some digging, I found the real problem. The SD card needs all images to be inside a folder called /images, and the code has to open paths like "/images/filename" for anything to load. I had been trying to open "test.bmp" directly, so it was never going to work.
Once I fixed the file path and pointed it to the images directory, everything started working normally.

<img width="468" height="287" alt="image" src="https://github.com/user-attachments/assets/f89d8fd4-6d47-4956-8149-f320b717eb7c" />

Image from: https://www.electronicwings.com/esp32/microsd-card-interfacing-with-esp32 


# 11-04-25
Started working on web app. Created a simple test utilizing the wifi library and webserver library.
*See Web_App_Test.ino in code*

# 11-06-25 
Compiled components that would work together to create a PCB of our design. Also started 3d-printing the sphere we would utilize.
*See csv file in KiCad folder*

![image](https://github.com/user-attachments/assets/1739855c-de8f-4ba1-a201-cb709a3342e9)

# 11-11-25
Created a schematic of all the components necessary for our design, making sure I had the right footprints 
*See sch file in KiCad folder*

<img width="468" height="285" alt="image" src="https://github.com/user-attachments/assets/05e3f5fd-2cda-48ab-aae4-5cac763bad5e" />

# 11-13-25

Made the first attempt at laying out the PCB and it did NOT pass DRC.
There were footprint inconsistencies, traces that were way too close together, and some components were placed in ways that made zero sense once I looked at it again.
Also learned the hard way that KiCad’s default design rules are very strict.
Designed the base of the globe and the motor shaft extender that would connect to the rotating part of the globe

<img width="182" height="168" alt="image" src="https://github.com/user-attachments/assets/3fe01587-0dcf-4e6b-8ffe-b52fa3cb5222" />\

<img width="46" height="152" alt="image" src="https://github.com/user-attachments/assets/530ca700-6fdc-4d93-97ed-277da5166d29" />




# 11-17-25

Went through and fixed all the DRC errors. Lowered the DRC strictness a bit since the default settings were catching way more issues than were actually relevant for our board house.
Cleaned up the routing, corrected the footprints that were mismatched, and reorganized components so the layout made more sense. After some tweaking, the board finally passed the DRC without complaining.
*See pcb in KiCad folder*  

<img width="264" height="295" alt="image" src="https://github.com/user-attachments/assets/ad11d789-2f35-4661-851c-9456205d607f" />

# 11-18-25

Objectives
	•	Design 3D-printable mechanical parts needed for the POV globe.
	•	Create a motor shaft mount that will hold the rotating base and LED globe.
	•	Create a magnet stand to set the hall-sensor timing magnet at a fixed height.

I designed two new 3D models for the mechanical assembly:
	1.	Motor Shaft Mount (Rotating Base Coupler):
	•	Designed a tight-fitting coupler that slips onto the motor shaft.
	•	This part will directly support the rotating base that carries the LEDs and electronics.
	2.	Magnet Stand:
	•	Simple vertical post with a small platform to hold the magnet used for rotation timing.
	•	Height set so the magnet passes the hall sensor consistently.
	•	Wide base to keep the stand stable during testing.

Both designs were printed quickly so I didn’t run detailed calculations or measurements beyond basic fit checks. After printing, I did quick trial fits and adjusted dimensions by reprinting the parts where needed.
*See magnet_stand and motor_shaft_thing files in CAD folder*

<img width="130" height="119" alt="image" src="https://github.com/user-attachments/assets/f5c3710c-a5e4-4120-ac1d-1e6d5aa5b6e6" />

<img width="111" height="118" alt="image" src="https://github.com/user-attachments/assets/53695fab-4e51-441c-93af-64e5cee219fd" />



# 11-20-25
In website added new functionality that makes sure the display functions are able to happen without interruption or in other words, images are able to be displayed in real time when a request is sent from the web application. It makes sure to read the data from the sd card and then change the image being displayed to the one chosen.

*See main.cpp in code*

# 12-1-25

Updated web application with instructions on how to upload an image to have the correct file format (bmp). 
*See webpage.h in code*

![image](https://github.com/user-attachments/assets/590f41c0-88ff-4afb-9d29-93b709b3ae5e)

![image](https://github.com/user-attachments/assets/64d865a7-7d2d-4f0e-9707-3b5b26a89acb)


# 12-2-25

Demoed to professor and TAs, finally spinning our final design. It looked promising but there was some friction between the spinning portion and the static base which kind of broke our design. To be more specifc, our led strip's wires came undone from its pads. Sadly, we gave up on trying to fix the mechanical issue since this is not an easy fix.

![image](https://github.com/user-attachments/assets/78310065-993b-4957-862c-50892e9e7e38)

![image](https://github.com/user-attachments/assets/97999192-58a5-4131-bae9-eeab3ff51f10)

<img width="219" height="397" alt="image" src="https://github.com/user-attachments/assets/de0aacf6-8344-4d98-adda-0a892339a159" />

